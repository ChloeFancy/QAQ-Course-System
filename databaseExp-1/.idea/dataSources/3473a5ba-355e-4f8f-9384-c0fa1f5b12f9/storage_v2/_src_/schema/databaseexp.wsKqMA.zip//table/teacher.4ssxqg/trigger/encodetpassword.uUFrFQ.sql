create trigger encodeTPassword
  before INSERT
  on teacher
  for each row
  BEGIN
    SET NEW.tPassword = md5(New.tPassword);
end;

