create trigger encodeSPassword
  before INSERT
  on student
  for each row
  BEGIN
    SET NEW.sPassword = md5(New.sPassword);
end;

