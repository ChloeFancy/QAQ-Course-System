create procedure increaseExamGrades(IN n float)
  BEGIN
    update Myscore set examResults = examResults * (1+n);
END;

