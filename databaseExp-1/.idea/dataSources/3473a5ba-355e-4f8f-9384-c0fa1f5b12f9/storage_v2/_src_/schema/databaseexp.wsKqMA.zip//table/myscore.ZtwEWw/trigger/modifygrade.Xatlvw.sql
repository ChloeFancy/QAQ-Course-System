create trigger modifyGrade
  after INSERT
  on myscore
  for each row
  BEGIN
    UPDATE Myscore SET totalResults = (usualResults+examResults)/2;
end;

