create trigger encodeAPassword
  before INSERT
  on administrator
  for each row
  BEGIN
    SET NEW.aPassword = md5(New.aPassword);
end;

