create trigger encodeSPasswordWhenUpdate
  before UPDATE
  on student
  for each row
  BEGIN
    SET NEW.sPassword = md5(New.sPassword);
end;

